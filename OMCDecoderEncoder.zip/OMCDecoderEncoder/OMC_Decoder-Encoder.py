#!/usr/bin/python3

from sys import platform
import os
import sys
import subprocess
import shutil

IN = os.path.join(os.getcwd(), '_In')
OUT = os.path.join(os.getcwd(), '_Out')
IN_OMC = os.path.join(os.getcwd(), '_InOMC')
OUT_OMC = os.path.join(os.getcwd(), '_OutOMC')
TOOLS = os.path.join(os.getcwd(), 'Tools')
JAR = os.path.join(os.getcwd(), 'Tools', 'omc-decoder.jar')
IS_WINDOWS = False

if platform == "linux" or platform == "linux2":
	IS_WINDOWS = False
elif platform == "darwin":
	IS_WINDOWS = False
elif platform == "win32":
	IS_WINDOWS = True

def clear():
	if IS_WINDOWS:
		os.system('cls')
	elif not IS_WINDOWS:
		os.system('clear')

def setupEnv():
	if not os.path.exists(IN):
		os.mkdir(IN)
	if not os.path.exists(OUT):
		os.mkdir(OUT)
	if not os.path.exists(IN_OMC):
		os.mkdir(IN_OMC)
	if not os.path.exists(OUT_OMC):
		os.mkdir(OUT_OMC)
	if not os.path.exists(JAR):
		print('omc-decoder.jar is missing, please extract Tools folder')
		sys.exit()

	try:
		subprocess.run(['java', '-version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
	except FileNotFoundError:
		print('Please install Java and make sure it\'s available in PATH')
		sys.exit()

def decode():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN):
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(OUT, file_)
				proc = subprocess.run('java -jar {} -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('Failed decode %s' % file_)
	print('')
	input('Done ! Press enter')
	print('')
	main()

def encode():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN):
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(OUT, file_)
				proc = subprocess.run('java -jar {} -e -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('Failed encode %s' % file_)
	print('')
	input('press enter')
	print('')
	main()

def decodeOMC():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN_OMC):
		dir_ = root.replace(IN_OMC, OUT_OMC)
		if not os.path.exists(dir_):
			os.mkdir(dir_)
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(dir_, file_)
				proc = subprocess.run('java -jar {} -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('Failed decode %s' % file_)
	print('')
	input('Done ! Press enter')
	print('')
	main()

def encodeOMC():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN_OMC):
		out_dirs = root.replace(IN_OMC, OUT_OMC)
		if not os.path.exists(out_dirs):
			os.mkdir(out_dirs)
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(out_dirs, file_)
				proc = subprocess.run('java -jar {} -e -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('Failed encode %s' % file_)
	print('')
	input('Done ! Press enter')
	print('')
	main()

def header():
	clear()
	print('******************************************************')
	print('*                                                    *')
	print('*     OMC Decoder Encoder by Yoanf26@PhonAndroid     *')
	print('*                                                    *')
	print('******************************************************')

def choice():
	print('')
	print('Do you want decode or encode your file(s) ?')
	print('')
	print('1. Decode (Your file(s) is/are in the "_In" folder)')
	print('2. Encode (Your file(s) is/are in the "_In" folder)')
	print('3. Decode Multiple OMC (Your XXX folders are in the "_InOMC" folder)')
	print('4. Encode Multiple OMC (Your XXX folders are in the "_InOMC" folder)')
	print('5. Quit')

	user_choice = input('Choose a number and press enter: ')

	return user_choice

def main():
	clear()
	print(JAR)
	setupEnv()
	header()
	user_choice = choice()
	try:
		user_choice = int(user_choice)
	except ValueError:
		main()

	if user_choice == 1:
		decode()
	elif user_choice == 2:
		encode()
	elif user_choice == 3:
		decodeOMC()
	elif user_choice == 4:
		encodeOMC()
	elif user_choice == 5:
		sys.exit()
	else:
		main()

if __name__ == "__main__":
	main()