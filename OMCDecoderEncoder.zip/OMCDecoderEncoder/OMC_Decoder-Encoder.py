#!/usr/bin/python3

from sys import platform
import os
import sys
import subprocess
import shutil

IN = os.path.join(os.getcwd(), '_In')
OUT = os.path.join(os.getcwd(), '_Out')
IN_OMC = os.path.join(os.getcwd(), '_InOMC')
OUT_OMC = os.path.join(os.getcwd(), '_OutOMC')
TOOLS = os.path.join(os.getcwd(), 'Tools')
JAR = os.path.join(os.getcwd(), 'Tools', 'omc-decoder.jar')
IS_WINDOWS = False

if platform == "linux" or platform == "linux2":
	IS_WINDOWS = False
elif platform == "darwin":
	IS_WINDOWS = False
elif platform == "win32":
	IS_WINDOWS = True

def clear():
	if IS_WINDOWS:
		os.system('cls')
	elif not IS_WINDOWS:
		os.system('clear')

def setupEnv():
	if not os.path.exists(IN):
		os.mkdir(IN)
	if not os.path.exists(OUT):
		os.mkdir(OUT)
	if not os.path.exists(IN_OMC):
		os.mkdir(IN_OMC)
	if not os.path.exists(OUT_OMC):
		os.mkdir(OUT_OMC)
	if not os.path.exists(JAR):
		print('\x1b[1;37;41momc-decoder.jar is missing, please extract Tools folder\x1b[0m')
		print('')
		input('Press enter')
		clear()
		sys.exit()

	try:
		subprocess.run(['java', '-version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
	except FileNotFoundError:
		print('\x1b[1;37;41mPlease install Java and make sure it\'s available in PATH\x1b[0m')
		print('')
		input('Press enter')
		clear()
		sys.exit()

def decode():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN):
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(OUT, file_)
				proc = subprocess.run('java -jar {} -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('\x1b[1;37;41mFailed decode\x1b[0m %s' % file_)
	print('')
	input('Done ! Press enter')
	print('')
	main()

def encode():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN):
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(OUT, file_)
				proc = subprocess.run('java -jar {} -e -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('\x1b[1;37;41mFailed encode\x1b[0m %s' % file_)
	print('')
	input('press enter')
	print('')
	main()

def decodeOMC():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN_OMC):
		dir_ = root.replace(IN_OMC, OUT_OMC)
		if not os.path.exists(dir_):
			os.mkdir(dir_)
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(dir_, file_)
				proc = subprocess.run('java -jar {} -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('\x1b[1;37;41mFailed decode\x1b[0m %s' % file_)
	print('')
	input('Done ! Press enter')
	print('')
	main()

def encodeOMC():
	clear()
	header()
	xml = ''
	xml_out = ''
	for root, dirs, files in os.walk(IN_OMC):
		out_dirs = root.replace(IN_OMC, OUT_OMC)
		if not os.path.exists(out_dirs):
			os.mkdir(out_dirs)
		for file_ in files:
			if 'cscfeature.xml' in file_ or 'cscfeature_network.xml' in file_:
				xml = os.path.join(root, file_)
				xml_out = os.path.join(out_dirs, file_)
				proc = subprocess.run('java -jar {} -e -i {} -o {}'.format(JAR, xml, xml_out), shell=True)
				if proc.returncode != 0:
					print('\x1b[1;37;41mFailed\x1b[0m encode %s' % file_)
	print('')
	input('Done ! Press enter')
	print('')
	main()

def header():
	clear()
	print('******************************************************')
	print('*                                                    *')
	print('*     \x1b[1;37;46mOMC Decoder Encoder by Yoanf26@PhonAndroid\x1b[0m     *')
	print('*                                                    *')
	print('******************************************************')

def choice():
	print('')
	print('Do you want decode or encode your file(s) ?')
	print('')
	print('\x1b[1;37;44m1\x1b[0m. Decode (Your file(s) is/are in the "_In" folder)')
	print('\x1b[1;37;44m2\x1b[0m. Encode (Your file(s) is/are in the "_In" folder)')
	print('\x1b[1;37;44m3\x1b[0m. Decode Multiple OMC (Your XXX folders are in the "_InOMC" folder)')
	print('\x1b[1;37;44m4\x1b[0m. Encode Multiple OMC (Your XXX folders are in the "_InOMC" folder)')
	print('\x1b[1;37;44m5\x1b[0m. Quit')

	user_choice = input('Choose a \x1b[1;37;44mnumber\x1b[0m and press enter: ')

	return user_choice

def main():
	clear()
	print(JAR)
	setupEnv()
	header()
	user_choice = choice()
	try:
		user_choice = int(user_choice)
	except ValueError:
		main()

	if user_choice == 1:
		decode()
	elif user_choice == 2:
		encode()
	elif user_choice == 3:
		decodeOMC()
	elif user_choice == 4:
		encodeOMC()
	elif user_choice == 5:
		clear()
		sys.exit()
	else:
		main()

if __name__ == "__main__":
	main()